void cmd_dir();
void cmd_help();
void cmd_reset();
int cmd_dump(int, int, int*);
int cmd_edit(int, int);
int cmd_fill(int, int, int);
int cmd_hashlistSearch(char*);