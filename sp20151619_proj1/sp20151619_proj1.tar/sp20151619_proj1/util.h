int checkRange(int);
int compareString(char*, char*, char*);
int checkComma(char*);
int checkHex(char*);
void LowerToUpper(char*);

